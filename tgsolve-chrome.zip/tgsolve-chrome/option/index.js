const TTG_HOST = "https://api.tgsolve.com";
const ACTIONS = ["nothing", "submit", "restart"];

const DEFAULT_CONFIG = {
  clientKey: "",
  host: TTG_HOST,
  autorun: true,
  imageclassification: false,
  hcaptcha: false,
  imagetotext: false,
  rainbow: false,
  times: 200,
  isTextCaptcha: false,
  endTimes: "20",
  isAutoClickCheckBox: true,
  checkBoxClickDelayTime: "500",
  isOpenEndTimes: true,
  isOpenCloudflare: false,
  isAutoSubmit: true,
  autoSubmitDelayTime: 100,
  autoSubmitDelayFloatRate: 0.1,
  workStatusFlag: "",
  jsControlObjectName: "tgsolveChorme",
  allowJsInject: false,
  network: {
    hcaptchaVerifyFailDelay: 1000,
    hcaptchaVerifyTry: 3,
    recaptchaVerifyFailDelay: 1000,
    recaptchaVerifyTry: 2,
    funcaptchaVerifyFailDelay: 1000,
    funcaptchaVerifyTry: 3
  },
  funcaptchaConfig: {
    isOpen: true,
    actionAfterRecSuccess: "nothing",
    actionAfterOneRecFail: "nothing",
    actionAfterRecFail: "nothing",
    actionDelay: 6000,
    isAutoClickPrePage: true
  },
  blackListConfig: { isOpen: false, urlList: [] },
  whiteListConfig: { isOpen: false, urlList: [] },
  awsCaptchaConfig: { isOpen: false },
  recaptchaConfig: { isOpen: false, isOpenProtocol: false },
  hcaptchaConfig: { isAutoRefresh: false },
  isHideKey: false
};

const PAGE_META = {
  general: ["General", "Account and runtime"],
  automation: ["Automation", "Click flow and limits"],
  funcaptcha: ["FunCaptcha", "Challenge behavior"],
  network: ["Network", "Retries and bridge"],
  scope: ["Scope", "Allow and block lists"]
};

let currentConfig = null;

function deepMerge(base, value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const output = { ...base };
  for (const key of Object.keys(value)) {
    const nextValue = value[key];
    if (
      nextValue &&
      typeof nextValue === "object" &&
      !Array.isArray(nextValue) &&
      base &&
      typeof base[key] === "object" &&
      !Array.isArray(base[key])
    ) {
      output[key] = deepMerge(base[key], nextValue);
    } else {
      output[key] = nextValue;
    }
  }
  return output;
}

function normalizeConfig(config) {
  const merged = deepMerge(DEFAULT_CONFIG, config || {});
  return {
    ...merged,
    host: TTG_HOST,
    imageclassification: false,
    hcaptcha: false,
    imagetotext: false,
    rainbow: false,
    isTextCaptcha: false,
    isOpenCloudflare: false,
    recaptchaConfig: { ...(merged.recaptchaConfig || {}), isOpen: false, isOpenProtocol: false },
    hcaptchaConfig: { ...(merged.hcaptchaConfig || {}), isAutoRefresh: false },
    awsCaptchaConfig: { ...(merged.awsCaptchaConfig || {}), isOpen: false },
    funcaptchaConfig: {
      ...DEFAULT_CONFIG.funcaptchaConfig,
      ...(merged.funcaptchaConfig || {})
    }
  };
}

function getStorage(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => resolve(result || {}));
  });
}

function setStorage(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, resolve);
  });
}

function getPath(object, path) {
  return path.split(".").reduce((value, key) => (value ? value[key] : undefined), object);
}

function setPath(object, path, value) {
  const keys = path.split(".");
  let cursor = object;
  for (let index = 0; index < keys.length - 1; index += 1) {
    const key = keys[index];
    cursor[key] = cursor[key] && typeof cursor[key] === "object" ? cursor[key] : {};
    cursor = cursor[key];
  }
  cursor[keys[keys.length - 1]] = value;
}

function parseNumber(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  const limitedMin = typeof min === "number" ? Math.max(min, number) : number;
  return typeof max === "number" ? Math.min(max, limitedMin) : limitedMin;
}

function parseList(value) {
  return String(value || "")
    .split(/\r?\n/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function setStatus(message, tone) {
  const el = document.getElementById("status");
  el.textContent = message || "";
  el.style.color = tone === "error" ? "var(--danger)" : "var(--muted)";
}

function bindSelectOptions() {
  for (const id of [
    "funcaptchaConfig.actionAfterRecSuccess",
    "funcaptchaConfig.actionAfterOneRecFail",
    "funcaptchaConfig.actionAfterRecFail"
  ]) {
    const select = document.getElementById(id);
    select.innerHTML = ACTIONS.map((action) => `<option value="${action}">${action}</option>`).join("");
  }
}

function fillInput(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  if (el.type === "checkbox") {
    el.checked = Boolean(value);
    return;
  }
  if (el.tagName === "TEXTAREA" && Array.isArray(value)) {
    el.value = value.join("\n");
    return;
  }
  el.value = value ?? "";
}

function fillForm(config) {
  for (const id of [
    "clientKey",
    "host",
    "autorun",
    "isHideKey",
    "allowJsInject",
    "isAutoClickCheckBox",
    "isAutoSubmit",
    "isOpenEndTimes",
    "times",
    "checkBoxClickDelayTime",
    "endTimes",
    "autoSubmitDelayTime",
    "autoSubmitDelayFloatRate",
    "funcaptchaConfig.isOpen",
    "funcaptchaConfig.isAutoClickPrePage",
    "funcaptchaConfig.actionAfterRecSuccess",
    "funcaptchaConfig.actionAfterOneRecFail",
    "funcaptchaConfig.actionAfterRecFail",
    "funcaptchaConfig.actionDelay",
    "network.funcaptchaVerifyFailDelay",
    "network.funcaptchaVerifyTry",
    "workStatusFlag",
    "jsControlObjectName",
    "whiteListConfig.isOpen",
    "blackListConfig.isOpen",
    "whiteListConfig.urlList",
    "blackListConfig.urlList"
  ]) {
    fillInput(id, getPath(config, id));
  }
}

function collectConfig() {
  const next = normalizeConfig(currentConfig);
  next.clientKey = document.getElementById("clientKey").value.trim();
  next.host = TTG_HOST;
  next.autorun = document.getElementById("autorun").checked;
  next.isHideKey = document.getElementById("isHideKey").checked;
  next.allowJsInject = document.getElementById("allowJsInject").checked;
  next.isAutoClickCheckBox = document.getElementById("isAutoClickCheckBox").checked;
  next.isAutoSubmit = document.getElementById("isAutoSubmit").checked;
  next.isOpenEndTimes = document.getElementById("isOpenEndTimes").checked;
  next.times = Math.floor(parseNumber(document.getElementById("times").value, DEFAULT_CONFIG.times, 100));
  next.checkBoxClickDelayTime = String(Math.floor(parseNumber(document.getElementById("checkBoxClickDelayTime").value, 500, 0)));
  next.endTimes = String(Math.floor(parseNumber(document.getElementById("endTimes").value, Number(DEFAULT_CONFIG.endTimes), 1)));
  next.autoSubmitDelayTime = Math.floor(parseNumber(document.getElementById("autoSubmitDelayTime").value, DEFAULT_CONFIG.autoSubmitDelayTime, 0));
  next.autoSubmitDelayFloatRate = parseNumber(document.getElementById("autoSubmitDelayFloatRate").value, DEFAULT_CONFIG.autoSubmitDelayFloatRate, 0, 1);
  next.workStatusFlag = document.getElementById("workStatusFlag").value.trim();
  next.jsControlObjectName = document.getElementById("jsControlObjectName").value.trim() || DEFAULT_CONFIG.jsControlObjectName;

  for (const id of [
    "funcaptchaConfig.isOpen",
    "funcaptchaConfig.isAutoClickPrePage",
    "funcaptchaConfig.actionAfterRecSuccess",
    "funcaptchaConfig.actionAfterOneRecFail",
    "funcaptchaConfig.actionAfterRecFail"
  ]) {
    const el = document.getElementById(id);
    setPath(next, id, el.type === "checkbox" ? el.checked : el.value);
  }

  setPath(next, "funcaptchaConfig.actionDelay", Math.floor(parseNumber(document.getElementById("funcaptchaConfig.actionDelay").value, DEFAULT_CONFIG.funcaptchaConfig.actionDelay, 0)));
  setPath(next, "network.funcaptchaVerifyFailDelay", Math.floor(parseNumber(document.getElementById("network.funcaptchaVerifyFailDelay").value, DEFAULT_CONFIG.network.funcaptchaVerifyFailDelay, 0)));
  setPath(next, "network.funcaptchaVerifyTry", Math.floor(parseNumber(document.getElementById("network.funcaptchaVerifyTry").value, DEFAULT_CONFIG.network.funcaptchaVerifyTry, 1)));

  setPath(next, "whiteListConfig.isOpen", document.getElementById("whiteListConfig.isOpen").checked);
  setPath(next, "blackListConfig.isOpen", document.getElementById("blackListConfig.isOpen").checked);
  setPath(next, "whiteListConfig.urlList", parseList(document.getElementById("whiteListConfig.urlList").value));
  setPath(next, "blackListConfig.urlList", parseList(document.getElementById("blackListConfig.urlList").value));

  return normalizeConfig(next);
}

async function save() {
  currentConfig = collectConfig();
  await setStorage({ config: currentConfig });
  fillForm(currentConfig);
  setStatus("Saved");
}

function switchPage(name) {
  for (const tab of document.querySelectorAll(".tab")) {
    tab.classList.toggle("active", tab.dataset.tab === name);
  }
  for (const page of document.querySelectorAll(".page")) {
    page.classList.toggle("active", page.dataset.page === name);
  }
  const meta = PAGE_META[name] || PAGE_META.general;
  document.getElementById("page-title").textContent = meta[0];
  document.getElementById("page-subtitle").textContent = meta[1];
}

async function init() {
  bindSelectOptions();
  const stored = await getStorage(["config"]);
  currentConfig = normalizeConfig(stored.config);
  fillForm(currentConfig);
  await setStorage({ config: currentConfig });

  for (const tab of document.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => switchPage(tab.dataset.tab));
  }

  document.getElementById("save-config").addEventListener("click", () => {
    save().catch((error) => setStatus(error.message || "Save failed", "error"));
  });

  document.getElementById("settings-form").addEventListener("submit", (event) => {
    event.preventDefault();
    save().catch((error) => setStatus(error.message || "Save failed", "error"));
  });

  document.getElementById("reset-defaults").addEventListener("click", async () => {
    currentConfig = normalizeConfig({
      ...DEFAULT_CONFIG,
      clientKey: currentConfig && currentConfig.clientKey ? currentConfig.clientKey : ""
    });
    fillForm(currentConfig);
    await setStorage({ config: currentConfig });
    setStatus("Defaults restored");
  });
}

document.addEventListener("DOMContentLoaded", () => {
  init().catch((error) => setStatus(error.message || "Failed to load", "error"));
});
