(() => {
    const realFetch = self.fetch.bind(self);
    const TGSOLVE_API_HOST = "api.tgsolve.com";
    const TGSOLVE_LEGACY_HOST = "tgsolve.com";
    const API_BASES = [
        `https://${TGSOLVE_API_HOST}/api/v1`,
        `https://${TGSOLVE_API_HOST}`,
        `https://${TGSOLVE_LEGACY_HOST}/api/v1`,
        `https://${TGSOLVE_LEGACY_HOST}`
    ];
    const POLL_INTERVAL_MS = 1500;
    const MAX_POLLS = 40;
    const FETCH_TIMEOUT_MS = 25000;

    function jsonResponse(data) {
        return new Response(JSON.stringify(data), {
            status: 200,
            headers: { "content-type": "application/json" }
        });
    }

    function isTgsolveUrl(url) {
        try {
            const hostname = new URL(url).hostname;
            return hostname === TGSOLVE_API_HOST || hostname === TGSOLVE_LEGACY_HOST;
        } catch (error) {
            return false;
        }
    }

    function stripDataUrl(value) {
        if (!value || typeof value !== "string") return "";
        const commaIndex = value.indexOf(",");
        return value.startsWith("data:") && commaIndex > -1 ? value.slice(commaIndex + 1) : value;
    }

    function getImageMeta(base64) {
        try {
            const binary = atob(base64);
            const bytes = Array.from(binary, (char) => char.charCodeAt(0));
            if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) {
                return {
                    format: "png",
                    width: (bytes[16] << 24) | (bytes[17] << 16) | (bytes[18] << 8) | bytes[19],
                    height: (bytes[20] << 24) | (bytes[21] << 16) | (bytes[22] << 8) | bytes[23]
                };
            }
            if (bytes[0] === 0xff && bytes[1] === 0xd8) {
                for (let index = 2; index + 9 < bytes.length;) {
                    if (bytes[index] !== 0xff) {
                        index += 1;
                        continue;
                    }
                    const marker = bytes[index + 1];
                    const length = (bytes[index + 2] << 8) + bytes[index + 3];
                    if ((marker >= 0xc0 && marker <= 0xc3) || (marker >= 0xc5 && marker <= 0xc7) || (marker >= 0xc9 && marker <= 0xcb) || (marker >= 0xcd && marker <= 0xcf)) {
                        return {
                            format: "jpeg",
                            width: (bytes[index + 7] << 8) + bytes[index + 8],
                            height: (bytes[index + 5] << 8) + bytes[index + 6]
                        };
                    }
                    index += 2 + length;
                }
                return { format: "jpeg" };
            }
        } catch (error) {
            return { format: "unknown" };
        }
        return { format: "unknown" };
    }

    function getTaskPayload(data) {
        const task = data && data.task ? data.task : {};
        const image =
            task.body ||
            task.queries ||
            task.image ||
            task.img ||
            data.body ||
            "";
        const instruction =
            task.imginstructions ||
            task.question ||
            task.comment ||
            task.prompt ||
            data.imginstructions ||
            task.type ||
            "funcaptcha-img";

        return {
            body: stripDataUrl(Array.isArray(image) ? image[0] : image),
            imginstructions: String(instruction || "funcaptcha-img")
        };
    }

    function parseAnswerList(answer) {
        let text = String(answer || "").trim();
        if (!text) return [];
        if (text.startsWith("OK|")) text = text.slice(3).trim();

        try {
            const parsed = JSON.parse(text);
            if (Array.isArray(parsed)) return parsed;
            if (parsed && Array.isArray(parsed.objects)) return parsed.objects;
            if (parsed && parsed.solution && Array.isArray(parsed.solution.objects)) {
                return parsed.solution.objects;
            }
            if (parsed && typeof parsed.answer === "string") return parseAnswerList(parsed.answer);
        } catch (error) {
            // Plain text is the normal tgsolve result format.
        }

        const numbers = text.match(/\d+/g);
        if (numbers && numbers.length) return numbers.map(Number).filter(Number.isFinite);

        return text
            .split(/[\s,|;]+/)
            .filter(Boolean)
            .map((item) => {
                const normalized = item.toLowerCase();
                if (["true", "yes", "y"].includes(normalized)) return true;
                if (["false", "no", "n"].includes(normalized)) return false;
                const number = Number(item);
                return Number.isFinite(number) ? number : item;
            });
    }

    function booleansToIndexes(values) {
        return values.reduce((indexes, value, index) => {
            const normalized = typeof value === "string" ? value.toLowerCase() : value;
            if (normalized === true || normalized === "true" || normalized === "yes" || normalized === "y") {
                indexes.push(index);
            }
            return indexes;
        }, []);
    }

    function parseFuncaptchaObjects(answer, instruction) {
        const values = parseAnswerList(answer);
        const text = String(instruction || "").toLowerCase();
        const isRotationTask = /rotate|旋转|转/.test(text);
        const isArrowFindTask = /use the arrows to find|find the image|left image exactly|找到图像|寻找图像/.test(text);
        const numericValues = values.map(Number).filter(Number.isFinite);
        const hasBooleanValues = values.some((value) => {
            const normalized = typeof value === "string" ? value.toLowerCase() : value;
            return normalized === true || normalized === false || normalized === "true" || normalized === "false";
        });

        if (isRotationTask) return numericValues;
        if (hasBooleanValues) return booleansToIndexes(values);
        if (isArrowFindTask && numericValues.length === 1) return [Math.max(0, numericValues[0] - 1)];
        if (numericValues.length === 1) return [Math.max(0, numericValues[0] - 1)];
        if (numericValues.includes(0)) return numericValues;
        return numericValues.map((value) => Math.max(0, value - 1));
    }

    function maskKey(key) {
        if (!key) return "";
        return `${key.slice(0, 8)}...${key.slice(-4)}`;
    }

    function normalizeKey(key) {
        return String(key || "").trim();
    }

    function errorResult(code, description, extra) {
        return {
            errorCode: code,
            errorId: 1,
            errorDescription: description || code,
            ...(extra || {})
        };
    }

    function looksLikeHtml(text) {
        return /^\s*<!doctype html/i.test(text || "") || /^\s*<html/i.test(text || "");
    }

    function shorten(text, maxLength = 160) {
        const value = String(text || "").replace(/\s+/g, " ").trim();
        return value.length > maxLength ? `${value.slice(0, maxLength)}...` : value;
    }

    async function fetchText(url, options) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
        try {
            const response = await realFetch(url, {
                ...(options || {}),
                cache: "no-store",
                signal: controller.signal
            });
            const text = (await response.text()).trim();
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${shorten(text || response.statusText)}`);
            }
            if (looksLikeHtml(text)) {
                throw new Error(`HTML response from API: ${shorten(text)}`);
            }
            return text;
        } finally {
            clearTimeout(timer);
        }
    }

    async function fetchApiText(path, options) {
        const errors = [];
        for (const base of API_BASES) {
            const url = `${base}/${path.replace(/^\/+/, "")}`;
            try {
                return await fetchText(url, options);
            } catch (error) {
                errors.push(`${base}: ${error && error.message ? error.message : String(error)}`);
            }
        }
        throw new Error(`Cannot reach tgsolve API. ${errors.join(" | ")}`);
    }

    async function submitToTgsolve(url, options) {
        const endpoint = new URL(url);
        const data = JSON.parse((options && options.body) || "{}");
        const key = normalizeKey(data.clientKey || endpoint.searchParams.get("key") || "");
        const payload = getTaskPayload(data);
        const taskType = data && data.task ? data.task.type : "";

        if (!key) {
            return errorResult("ERROR_KEY_DOES_NOT_EXIST", "Missing tgsolve API key");
        }

        if (!payload.body) {
            return errorResult("ERROR_REQUIRED_FIELDS", "Missing base64 image body");
        }

        const form = new URLSearchParams();
        form.set("type-captcha", "funcaptcha-img");
        form.set("method", "base64");
        form.set("body", payload.body);
        form.set("imginstructions", payload.imginstructions);
        form.set("requestId", data.requestId || `${Date.now()}-${Math.random().toString(36).slice(2)}`);

        const imageMeta = getImageMeta(payload.body);
        console.log("[tgsolve-adapter] submit", {
            key: maskKey(key),
            taskType,
            originalTaskKeys: Object.keys((data && data.task) || {}),
            mappedFields: ["type-captcha", "method", "body", "imginstructions", "requestId"],
            captchaType: "funcaptcha-img",
            method: "base64",
            instruction: payload.imginstructions,
            bodyLength: payload.body.length,
            imageMeta
        });

        let submitText = "";
        try {
            submitText = await fetchApiText(`in.php?key=${encodeURIComponent(key)}`, { method: "POST", body: form });
        } catch (error) {
            return errorResult(
                "ERROR_TGSOLVE_NETWORK",
                `ERROR_TGSOLVE_NETWORK for ${maskKey(key)}: ${error && error.message ? error.message : String(error)}`
            );
        }
        console.log("[tgsolve-adapter] raw submit response", submitText);

        if (!submitText.startsWith("OK|")) {
            const code = submitText || "ERROR_TGSOLVE_SUBMIT";
            return errorResult(code, `${code} (${maskKey(key)})`);
        }

        const taskId = submitText.split("|")[1];
        for (let poll = 0; poll < MAX_POLLS; poll += 1) {
            await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));

            let resultText = "";
            try {
                resultText = await fetchApiText(`res.php?key=${encodeURIComponent(key)}&action=get&id=${encodeURIComponent(taskId)}`);
            } catch (error) {
                return errorResult(
                    "ERROR_TGSOLVE_NETWORK",
                    `ERROR_TGSOLVE_NETWORK for ${maskKey(key)}: ${error && error.message ? error.message : String(error)}`,
                    { taskId }
                );
            }
            console.log("[tgsolve-adapter] raw poll response", resultText);
            console.log("[tgsolve-adapter] poll", { taskId, resultText });

            if (!resultText || resultText === "CAPCHA_NOT_READY" || resultText === "CAPTCHA_NOT_READY") continue;

            if (resultText.startsWith("ERROR_")) {
                return errorResult(resultText, `${resultText} (${maskKey(key)})`, { taskId });
            }

            const answerText = resultText.startsWith("OK|") ? resultText.slice(3).trim() : resultText;
            const objects = parseFuncaptchaObjects(answerText, payload.imginstructions);
            console.log("[tgsolve-adapter] adapted solution", {
                taskId,
                rawText: resultText,
                text: answerText,
                objects
            });
            return {
                errorCode: 0,
                errorId: 0,
                taskId,
                solution: {
                    objects,
                    text: answerText,
                    rawText: resultText
                }
            };
        }

        return errorResult("ERROR_TGSOLVE_TIMEOUT", "tgsolve result polling timed out", { taskId });
    }

    async function getBalance(url, options) {
        let key = "";
        try {
            const data = options && options.body ? JSON.parse(options.body) : {};
            key = normalizeKey(data.clientKey || "");
        } catch (error) {
            key = "";
        }
        key = normalizeKey(key || new URL(url).searchParams.get("key") || "");
        if (!key) return errorResult("ERROR_KEY_DOES_NOT_EXIST", "Missing tgsolve API key", { balance: 0 });

        let text = "";
        try {
            text = await fetchApiText(`res.php?key=${encodeURIComponent(key)}&action=getbalance`);
        } catch (error) {
            return errorResult(
                "ERROR_TGSOLVE_NETWORK",
                `ERROR_TGSOLVE_NETWORK for ${maskKey(key)}: ${error && error.message ? error.message : String(error)}`,
                { balance: 0 }
            );
        }
        console.log("[tgsolve-adapter] raw balance response", text);
        const balance = Number(text);
        return Number.isFinite(balance) ? { errorCode: 0, errorId: 0, balance } : errorResult(text, `${text} (${maskKey(key)})`, { balance: 0 });
    }

    self.fetch = async (input, options) => {
        const url = typeof input === "string" ? input : input && input.url;
        if (!url || !isTgsolveUrl(url)) return realFetch(input, options);

        const path = new URL(url).pathname.toLowerCase();
        try {
            if (path.endsWith("/createtask") || path.endsWith("createtask")) {
                return jsonResponse(await submitToTgsolve(url, options));
            }
            if (path.endsWith("/getbalance") || path.endsWith("getbalance") || path.endsWith("/balance")) {
                return jsonResponse(await getBalance(url, options));
            }
            if (path.endsWith("/report") || path.endsWith("report")) {
                return jsonResponse({ errorCode: 0, errorId: 0, status: "ok" });
            }
        } catch (error) {
            return jsonResponse({
                errorCode: "ERROR_TGSOLVE_ADAPTER",
                errorId: 1,
                errorDescription: error && error.message ? error.message : String(error)
            });
        }

        return jsonResponse({ errorCode: 0, errorId: 0, status: "ok" });
    };
})();
