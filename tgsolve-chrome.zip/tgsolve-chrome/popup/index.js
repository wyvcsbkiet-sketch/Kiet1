const TTG_HOST = "https://api.tgsolve.com";
const TTG_WEB_HOST = "https://tgsolve.com";

const DEFAULT_CONFIG = {
  clientKey: "",
  host: TTG_HOST,
  autorun: true,
  imageclassification: false,
  hcaptcha: false,
  imagetotext: false,
  rainbow: false,
  times: 200,
  isTextCaptcha: false,
  endTimes: "20",
  isAutoClickCheckBox: true,
  checkBoxClickDelayTime: "500",
  isOpenEndTimes: true,
  isOpenCloudflare: false,
  isAutoSubmit: true,
  autoSubmitDelayTime: 100,
  autoSubmitDelayFloatRate: 0.1,
  workStatusFlag: "",
  jsControlObjectName: "tgsolveChorme",
  allowJsInject: false,
  network: {
    hcaptchaVerifyFailDelay: 1000,
    hcaptchaVerifyTry: 3,
    recaptchaVerifyFailDelay: 1000,
    recaptchaVerifyTry: 2,
    funcaptchaVerifyFailDelay: 1000,
    funcaptchaVerifyTry: 3
  },
  funcaptchaConfig: {
    isOpen: true,
    actionAfterRecSuccess: "nothing",
    actionAfterOneRecFail: "nothing",
    actionAfterRecFail: "nothing",
    actionDelay: 6000,
    isAutoClickPrePage: true
  },
  blackListConfig: { isOpen: false, urlList: [] },
  whiteListConfig: { isOpen: false, urlList: [] },
  awsCaptchaConfig: { isOpen: false },
  recaptchaConfig: { isOpen: false, isOpenProtocol: false },
  hcaptchaConfig: { isAutoRefresh: false },
  isHideKey: false
};

let currentConfig = null;
let saveTimer = null;
let balanceTimer = null;
let balanceRequestId = 0;
let balanceIntervalId = null;

function deepMerge(base, value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const output = { ...base };
  for (const key of Object.keys(value)) {
    const nextValue = value[key];
    if (
      nextValue &&
      typeof nextValue === "object" &&
      !Array.isArray(nextValue) &&
      base &&
      typeof base[key] === "object" &&
      !Array.isArray(base[key])
    ) {
      output[key] = deepMerge(base[key], nextValue);
    } else {
      output[key] = nextValue;
    }
  }
  return output;
}

function normalizeConfig(config) {
  const merged = deepMerge(DEFAULT_CONFIG, config || {});
  return {
    ...merged,
    host: TTG_HOST,
    imageclassification: false,
    hcaptcha: false,
    imagetotext: false,
    rainbow: false,
    isTextCaptcha: false,
    isOpenCloudflare: false,
    recaptchaConfig: { ...(merged.recaptchaConfig || {}), isOpen: false, isOpenProtocol: false },
    hcaptchaConfig: { ...(merged.hcaptchaConfig || {}), isAutoRefresh: false },
    awsCaptchaConfig: { ...(merged.awsCaptchaConfig || {}), isOpen: false },
    funcaptchaConfig: {
      ...DEFAULT_CONFIG.funcaptchaConfig,
      ...(merged.funcaptchaConfig || {})
    }
  };
}

function getStorage(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => resolve(result || {}));
  });
}

function setStorage(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, resolve);
  });
}

function setStatus(message, tone) {
  const el = document.getElementById("status-message");
  el.textContent = message || "";
  el.style.color = tone === "error" ? "var(--danger)" : "var(--muted)";
}

function numberFrom(id, fallback, min) {
  const value = Number(document.getElementById(id).value);
  if (!Number.isFinite(value)) return fallback;
  return Math.max(min, Math.floor(value));
}

function collectConfig() {
  const next = normalizeConfig(currentConfig);
  next.clientKey = document.getElementById("client-key").value.trim();
  next.autorun = document.getElementById("autorun").checked;
  next.times = numberFrom("click-delay", DEFAULT_CONFIG.times, 100);
  next.endTimes = String(numberFrom("attempt-limit", Number(DEFAULT_CONFIG.endTimes), 1));
  next.isAutoClickCheckBox = document.getElementById("auto-open").checked;
  next.isAutoSubmit = document.getElementById("auto-submit").checked;
  next.funcaptchaConfig = {
    ...next.funcaptchaConfig,
    isOpen: document.getElementById("funcaptcha-enabled").checked
  };
  return next;
}

async function saveConfig() {
  currentConfig = collectConfig();
  await setStorage({ config: currentConfig });
  renderRuntimeStatus();
  setStatus("Saved");
}

function scheduleSave() {
  setStatus("Saving...");
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveConfig().catch((error) => setStatus(error.message || "Save failed", "error"));
  }, 220);
}

function scheduleBalanceRefresh(delayMs = 650) {
  clearTimeout(balanceTimer);
  balanceTimer = setTimeout(() => {
    refreshBalance({ silentMissingKey: true }).catch((error) => {
      setStatus(error.message || "Balance refresh failed", "error");
    });
  }, delayMs);
}

function normalizeHost(host) {
  const raw = String(host || TTG_HOST).trim();
  const withProtocol = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
  return withProtocol.replace(/\/+$/, "");
}

function buildBalanceUrls(config) {
  const host = normalizeHost(config.host);
  const root = host.replace(/\/api\/v1$/i, "");
  return [`${root}/api/v1/res.php`, `${root}/res.php`];
}

function formatBalance(value) {
  const text = String(value ?? "").trim();
  return text || "0";
}

function maskKey(key) {
  const value = String(key || "").trim();
  if (!value) return "No key saved";
  if (value.length <= 12) return value;
  return `${value.slice(0, 8)}...${value.slice(-4)}`;
}

function shorten(text, maxLength = 120) {
  const value = String(text || "").replace(/\s+/g, " ").trim();
  return value.length > maxLength ? `${value.slice(0, maxLength)}...` : value;
}

function looksLikeHtml(text) {
  return /^\s*<!doctype html/i.test(text || "") || /^\s*<html/i.test(text || "");
}

function updateKeyHint() {
  const hint = document.getElementById("key-hint");
  if (!hint) return;
  hint.textContent = `Using key: ${maskKey(document.getElementById("client-key").value)}`;
}

async function fetchBalanceText(key) {
  const params = new URLSearchParams({ key, action: "getbalance" });
  const errors = [];
  for (const url of buildBalanceUrls(currentConfig)) {
    try {
      const response = await fetch(`${url}?${params.toString()}`, {
        method: "GET",
        cache: "no-store"
      });
      const text = (await response.text()).trim();
      if (!response.ok) throw new Error(`HTTP ${response.status}: ${shorten(text || response.statusText)}`);
      if (looksLikeHtml(text)) throw new Error(`HTML response: ${shorten(text)}`);
      return text;
    } catch (error) {
      errors.push(`${url}: ${error && error.message ? error.message : String(error)}`);
    }
  }
  throw new Error(errors.join(" | "));
}

async function refreshBalance(options = {}) {
  const balanceEl = document.getElementById("balance");
  const key = document.getElementById("client-key").value.trim();
  updateKeyHint();
  if (!key) {
    balanceEl.textContent = "0";
    setStatus(options.silentMissingKey ? "Enter API key to sync balance" : "API key required", options.silentMissingKey ? undefined : "error");
    return;
  }

  const requestId = balanceRequestId + 1;
  balanceRequestId = requestId;
  balanceEl.textContent = "...";
  let text = "";
  try {
    text = await fetchBalanceText(key);
  } catch (error) {
    if (requestId !== balanceRequestId) return;
    balanceEl.textContent = "0";
    setStatus(`Network error for ${maskKey(key)}: ${shorten(error && error.message ? error.message : String(error))}`, "error");
    return;
  }
  if (requestId !== balanceRequestId) return;
  if (/^ERROR/i.test(text)) {
    balanceEl.textContent = "0";
    setStatus(`${text || "ERROR_BALANCE"} (${maskKey(key)})`, "error");
    return;
  }

  balanceEl.textContent = formatBalance(text);
  setStatus(`Balance updated (${maskKey(key)})`);
}

function renderRuntimeStatus() {
  const status = document.getElementById("runtime-status");
  const hasKey = Boolean(document.getElementById("client-key").value.trim());
  const enabled = document.getElementById("autorun").checked && document.getElementById("funcaptcha-enabled").checked;
  status.textContent = hasKey && enabled ? "Ready" : "Offline";
  status.style.color = hasKey && enabled ? "var(--accent)" : "var(--accent-2)";
  updateKeyHint();
}

function fillForm(config) {
  document.getElementById("client-key").value = config.clientKey || "";
  document.getElementById("autorun").checked = Boolean(config.autorun);
  document.getElementById("funcaptcha-enabled").checked = Boolean(config.funcaptchaConfig && config.funcaptchaConfig.isOpen);
  document.getElementById("auto-open").checked = Boolean(config.isAutoClickCheckBox);
  document.getElementById("auto-submit").checked = Boolean(config.isAutoSubmit);
  document.getElementById("click-delay").value = config.times || DEFAULT_CONFIG.times;
  document.getElementById("attempt-limit").value = config.endTimes || DEFAULT_CONFIG.endTimes;
  renderRuntimeStatus();
}

async function init() {
  const stored = await getStorage(["config"]);
  currentConfig = normalizeConfig(stored.config);
  fillForm(currentConfig);
  await setStorage({ config: currentConfig });

  for (const id of ["autorun", "funcaptcha-enabled", "auto-open", "auto-submit", "click-delay", "attempt-limit"]) {
    const el = document.getElementById(id);
    el.addEventListener("input", scheduleSave);
    el.addEventListener("change", scheduleSave);
  }

  const keyInput = document.getElementById("client-key");
  keyInput.addEventListener("input", () => {
    scheduleSave();
    renderRuntimeStatus();
    scheduleBalanceRefresh();
  });
  keyInput.addEventListener("change", () => {
    scheduleSave();
    renderRuntimeStatus();
    scheduleBalanceRefresh(100);
  });

  document.getElementById("toggle-key").addEventListener("click", () => {
    const input = document.getElementById("client-key");
    const isHidden = input.type === "password";
    input.type = isHidden ? "text" : "password";
    document.getElementById("toggle-key").setAttribute("title", isHidden ? "Hide API key" : "Show API key");
  });

  document.getElementById("open-options").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });

  document.getElementById("open-dashboard").addEventListener("click", () => {
    chrome.tabs.create({ url: TTG_WEB_HOST, active: true });
  });

  document.getElementById("refresh-balance").addEventListener("click", () => {
    saveConfig()
      .then(refreshBalance)
      .catch((error) => setStatus(error.message || "Refresh failed", "error"));
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.config || !changes.config.newValue) return;
    currentConfig = normalizeConfig(changes.config.newValue);
    const activeElement = document.activeElement;
    const isEditing = activeElement && ["INPUT", "SELECT", "TEXTAREA"].includes(activeElement.tagName);
    if (isEditing) renderRuntimeStatus();
    else fillForm(currentConfig);
    scheduleBalanceRefresh(100);
  });

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) scheduleBalanceRefresh(100);
  });

  balanceIntervalId = setInterval(() => {
    if (!document.hidden) scheduleBalanceRefresh(0);
  }, 30000);

  window.addEventListener("pagehide", () => {
    clearInterval(balanceIntervalId);
    clearTimeout(balanceTimer);
  });

  refreshBalance({ silentMissingKey: true }).catch(() => {
    document.getElementById("balance").textContent = "0";
  });
}

document.addEventListener("DOMContentLoaded", () => {
  init().catch((error) => setStatus(error.message || "Failed to load", "error"));
});
